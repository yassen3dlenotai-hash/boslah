# Implementation Plan - Mushaf Page Order, Performance Profiles & Advanced Tajweed Analysis

## 1. Overview & Objectives
This plan outlines the implementation of three major enhancements requested by the user:
1. **Mushaf Page Ordering & RTL Progression Fix**: Verify and ensure proper logical and visual progression of pages from right to left (Page 1 Al-Fatihah on right, Page 2 on left, matching King Fahd Complex Madinah Mushaf order).
2. **Device Performance Profile System**: Add a startup popup modal on first launch (persisted locally, with a settings toggle) offering **Light Mode (جهاز ضعيف)** and **Performance Mode (جهاز قوي)** to optimize memory, prefetching, and animation overhead on low-end devices without sacrificing core reading features or SVG quality.
3. **Advanced Recitation & Tajweed Analysis Engine**: Upgrade the audio alignment and analysis backend in `server.ts` and frontend aligner (`recitationAligner.ts`) to perform rigorous Hafs-compliant phoneme, harakah (vowel), madd (elongation timing), and tajweed evaluation, displaying subtle word-level underlines and color tints on the Mushaf page.

---

## 2. Proposed Changes

### Part 1: Mushaf Page Order & RTL Progression Audit
- Inspect page loading and index mapping in `src/lib/mushafStore.ts` and `src/components/MushafSvgStage.tsx`.
- Ensure single-page and continuous modes display pages according to canonical Islamic reading order (Page 1 = Surah Al-Fatihah, Page 604 = Surah An-Nas).
- Verify swipe and pagination handlers correspond correctly to RTL book progression.

### Part 2: Device Performance Profile System
- **Profile State & Storage (`src/lib/performanceProfile.ts`)**:
  - Define `PerformanceProfile` type (`'light' | 'performance'`).
  - Manage persistence in `localStorage` (`mushaf-performance-profile-v1`).
- **First-Launch Modal (`src/components/PerformanceSetupModal.tsx`)**:
  - Popup dialog modal appearing on first launch if no profile is saved.
  - Options: Light Mode (optimized for lower memory, lightweight transitions, reduced prefetching) vs. Performance Mode (full 3D page curl, pixelated glass blur, smart background prefetch).
- **Settings Integration (`src/components/FloatingSettingsSheet.tsx`)**:
  - Add profile switcher toggle in settings.
- **Runtime Adaptations (`App.tsx`, `MushafSvgStage.tsx`, `BottomControlDock.tsx`)**:
  - Pass `performanceProfile` down to stage and UI components.
  - In Light Mode: disable heavy 3D page curl animations in favor of smooth instant or opacity slide transitions, limit LRU cache size to 4 pages instead of 8, disable continuous background prefetch beyond immediate neighbor, use simplified backdrop styling.
  - In Performance Mode: full 3D page curl, 8-page LRU cache, full background prefetching.

### Part 3: Advanced Recitation & Tajweed Analysis Engine
- **Backend Enhancements (`server.ts`)**:
  - Upgrade Gemini prompt instructions and structured JSON output for recitation evaluation to explicitly report:
    - `wordMatch` (exact vs. letter substitution vs. missing/added letters).
    - `harakahAnalysis` (correct damma/fatha/kasra/sukun/tanween/shaddah vs mismatch).
    - `maddAnalysis` (natural vs. secondary madd duration/harakat count estimation).
    - `tajweedRules` (noon sakinah rulings, qلقلة, غنة).
- **Frontend Aligner (`src/lib/recitationAligner.ts`)**:
  - Process detailed server breakdown into structured word-level error flags (`harakah_mismatch`, `letter_substitution`, `madd_length_error`, `tajweed_rule_error`).
- **Visual Feedback (`src/components/MushafSvgStage.tsx` / Ayah Overlay)**:
  - Render subtle, elegant word-level underline and color tint (amber for harakah/tajweed, red for letter/word error) directly under the targeted word polygon without blocking reading or SVG clarity.

---

## 3. Verification Plan

### Automated Tests (`tests/mushafEngine.test.ts`)
- Add unit tests for performance profile storage and defaults.
- Test advanced recitation aligner with harakah mismatch, madd length validation, and tajweed rule diagnostics.
- Run `npx tsx --test tests/mushafEngine.test.ts`.

### Manual & Build Verification
- Run `compile_applet` and `lint_applet` to ensure zero compilation or type errors.
- Verify startup performance modal appears on first load, saves state, and updates settings.
- Verify page 1 and page 2 order matches correct Madinah Mushaf right-to-left layout.
- Test recitation microphone recording and word-level subtle underline feedback.
