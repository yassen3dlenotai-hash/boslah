import crypto from 'node:crypto';
import {GoogleGenAI, ThinkingLevel, Type} from '@google/genai';
import {
  alignRecitationWords,
  applyAcousticMakhrajAndTajweedAudit,
  extractSensitiveTajweedTargets,
  type AcousticMakhrajFinding,
  type ExpectedAyahText,
  type SpokenWordObservation,
  type TajweedRuleEvaluation,
} from '../../src/lib/recitationAligner.ts';

const TOTAL_PAGES = 604;
const QURAN_SVG_BASE =
  'https://raw.githubusercontent.com/quran-ws/quran-svg/main/mushafs/hafs/kfqc';
const ALQURAN_CLOUD_BASE = 'https://api.alquran.cloud/v1';

interface ResolvedModelsCache {
  expiresAt: number;
  selectedModel: string | null;
  candidateModels: string[];
  availableModels: string[];
}

let modelsCache: ResolvedModelsCache | null = null;

function jsonResponse(payload: unknown, status = 200, extraHeaders?: Record<string, string>): Response {
  return new Response(JSON.stringify(payload), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      ...extraHeaders,
    },
  });
}

function pageCode(page: number): string {
  return String(page).padStart(3, '0');
}

function sha256(content: string): string {
  return crypto.createHash('sha256').update(content).digest('hex');
}

function createGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function resolveVerifiedAudioModel(ai: GoogleGenAI): Promise<{
  selectedModel: string | null;
  candidateModels: string[];
  availableModels: string[];
}> {
  if (modelsCache && Date.now() < modelsCache.expiresAt) {
    return {
      selectedModel: modelsCache.selectedModel,
      candidateModels: modelsCache.candidateModels,
      availableModels: modelsCache.availableModels,
    };
  }

  const availableModels: string[] = [];
  const pager = await ai.models.list();
  for await (const model of pager) {
    if (model.name) {
      availableModels.push(model.name.replace(/^models\//, ''));
    }
    if (availableModels.length >= 80) break;
  }

  const preferredOrder = [
    'gemini-4-hydrogen',
    'gemini-3-flash-preview',
    'gemini-3.1-flash-lite',
    'gemini-3.1-flash-lite-preview',
    'gemini-flash-latest',
    'gemini-3.5-transcribe',
  ];

  const candidateModels = preferredOrder.filter((candidate) =>
    availableModels.includes(candidate)
  );

  for (const m of availableModels) {
    if (
      !candidateModels.includes(m) &&
      !m.startsWith('gemini-2.5-') &&
      !m.includes('image') &&
      !m.includes('tts') &&
      (m.includes('flash') || m.includes('hydrogen') || m.includes('transcribe'))
    ) {
      candidateModels.push(m);
    }
  }

  const selectedModel = candidateModels[0] ?? null;
  modelsCache = {
    expiresAt: Date.now() + 3 * 60 * 1000,
    selectedModel,
    candidateModels,
    availableModels,
  };
  return {selectedModel, candidateModels, availableModels};
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | null = null;
  return new Promise<T>((resolve, reject) => {
    timer = setTimeout(() => {
      reject(new Error(`${label} timed out after ${timeoutMs}ms`));
    }, timeoutMs);
    promise.then(
      (value) => {
        if (timer) clearTimeout(timer);
        resolve(value);
      },
      (err) => {
        if (timer) clearTimeout(timer);
        reject(err);
      }
    );
  });
}

function isRetryableModelError(err: unknown): boolean {
  const msg = (err instanceof Error ? err.message : String(err)).toLowerCase();
  return (
    msg.includes('404') ||
    msg.includes('not_found') ||
    msg.includes('not supported') ||
    msg.includes('503') ||
    msg.includes('unavailable') ||
    msg.includes('high demand') ||
    msg.includes('429') ||
    msg.includes('resource_exhausted') ||
    msg.includes('deadline_exceeded') ||
    msg.includes('timed out') ||
    msg.includes('timeout') ||
    msg.includes('econnreset') ||
    msg.includes('overloaded')
  );
}

interface AlQuranCloudAyah {
  number: number;
  numberInSurah: number;
  text: string;
  surah: {
    number: number;
    name: string;
  };
}

async function handleMushafPage(page: number): Promise<Response> {
  const code = pageCode(page);
  const [svgRes, jsonRes] = await Promise.all([
    fetch(`${QURAN_SVG_BASE}/svg/${code}.svg`),
    fetch(`${QURAN_SVG_BASE}/json/${code}.json`),
  ]);

  if (!svgRes.ok || !jsonRes.ok) {
    return jsonResponse(
      {error: `Upstream fetch failed for page ${code} (${svgRes.status}/${jsonRes.status})`},
      502
    );
  }

  const svg = await svgRes.text();
  const jsonRaw = await jsonRes.text();
  if (!svg.includes('<svg')) {
    return jsonResponse({error: `Invalid SVG payload for page ${code}`}, 502);
  }
  const ayahs = JSON.parse(jsonRaw);
  if (!Array.isArray(ayahs)) {
    return jsonResponse({error: `Invalid JSON payload for page ${code}`}, 502);
  }

  return jsonResponse(
    {
      page,
      svg,
      ayahs,
      sha256Svg: sha256(svg),
      sha256Json: sha256(jsonRaw),
      cached: false,
    },
    200,
    {'Cache-Control': 'public, max-age=86400'}
  );
}

async function handleTafsirPage(page: number): Promise<Response> {
  const [muyassarRes, uthmaniRes] = await Promise.all([
    fetch(`${ALQURAN_CLOUD_BASE}/page/${page}/ar.muyassar`),
    fetch(`${ALQURAN_CLOUD_BASE}/page/${page}/quran-uthmani`),
  ]);

  if (!muyassarRes.ok || !uthmaniRes.ok) {
    return jsonResponse({error: `Failed to fetch Tafsir Al-Muyassar for page ${page}`}, 502);
  }

  const muyassarJson = (await muyassarRes.json()) as {data?: {ayahs?: AlQuranCloudAyah[]}};
  const uthmaniJson = (await uthmaniRes.json()) as {data?: {ayahs?: AlQuranCloudAyah[]}};

  const tafsirAyahs = muyassarJson.data?.ayahs ?? [];
  const uthmaniAyahs = uthmaniJson.data?.ayahs ?? [];

  const combined = uthmaniAyahs.map((item, idx) => {
    const tafsirMatch =
      tafsirAyahs.find(
        (t) => t.surah.number === item.surah.number && t.numberInSurah === item.numberInSurah
      ) ?? tafsirAyahs[idx];

    return {
      globalNumber: item.number,
      surahNumber: item.surah.number,
      surahName: item.surah.name,
      ayahNumber: item.numberInSurah,
      text: item.text,
      tafsirMuyassar: tafsirMatch?.text ?? '',
    };
  });

  return jsonResponse(
    {
      page,
      edition: 'ar.muyassar',
      ayahs: combined,
      sha256: sha256(JSON.stringify(combined)),
    },
    200,
    {'Cache-Control': 'public, max-age=86400'}
  );
}

async function handleRecitationStatus(): Promise<Response> {
  const ai = createGeminiClient();
  if (!ai) {
    return jsonResponse({
      available: false,
      reason: 'مفتاح GEMINI_API_KEY غير مضبوط في متغيرات البيئة على الخادم (Netlify Environment Variables).',
      selectedModel: null,
      availableModels: [],
    });
  }

  try {
    const {selectedModel, availableModels} = await resolveVerifiedAudioModel(ai);
    return jsonResponse({
      available: selectedModel !== null,
      reason: selectedModel
        ? null
        : 'لم يتم العثور على نموذج صوتي متوافق ضمن النماذج المفعلة على المفتاح.',
      selectedModel,
      availableModels: availableModels.slice(0, 20),
    });
  } catch (err) {
    return jsonResponse({
      available: false,
      reason: err instanceof Error ? err.message : 'تعذر التحقق من نماذج Google AI Studio API.',
      selectedModel: null,
      availableModels: [],
    });
  }
}

async function handleRecitationAnalyze(req: Request): Promise<Response> {
  const ai = createGeminiClient();
  if (!ai) {
    return jsonResponse(
      {
        error: 'محرك الذكاء الاصطناعي غير مهيأ: يرجى إضافة GEMINI_API_KEY في إعدادات متغيرات البيئة في Netlify.',
      },
      503
    );
  }

  let body: {
    audioBase64?: string;
    mimeType?: string;
    expectedAyahs?: ExpectedAyahText[];
    focusSurahNumber?: number;
    focusAyahNumber?: number;
  };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return jsonResponse({error: 'تعذر قراءة بيانات الطلب بصيغة JSON.'}, 400);
  }

  const {audioBase64, mimeType, expectedAyahs, focusSurahNumber, focusAyahNumber} = body;
  if (!audioBase64 || !Array.isArray(expectedAyahs) || expectedAyahs.length === 0) {
    return jsonResponse({error: 'Audio payload and expected ayahs are required.'}, 400);
  }

  try {
    if ((mimeType || '').includes('wav')) {
      const rawBytes = Buffer.from(audioBase64, 'base64');
      if (rawBytes.length > 44) {
        let peak = 0;
        for (let i = 44; i + 1 < rawBytes.length; i += 2) {
          const sample = Math.abs(rawBytes.readInt16LE(i));
          if (sample > peak) peak = sample;
          if (peak > 120) break;
        }
        if (peak <= 120) {
          const silentAlignment = alignRecitationWords([], expectedAyahs, {
            audioClarity: 'unintelligible',
            focusSurahNumber,
            focusAyahNumber,
          });
          return jsonResponse({
            modelUsed: 'silence-guard',
            alignment: silentAlignment,
            tajweedStatus: {
              calibrated: false,
              correctCount: 0,
              needsAttentionCount: 0,
              uncertainCount: 0,
              findings: [],
              note: 'الصوت صامت أو غير واضح — يرجى القراءة بصوت مسموع لفحص المخارج والتجويد.',
            },
          });
        }
      }
    }

    const {candidateModels} = await resolveVerifiedAudioModel(ai);
    if (candidateModels.length === 0) {
      return jsonResponse(
        {error: 'لم يتم العثور على نموذج صوتي متاح عبر Google AI Studio API.'},
        503
      );
    }

    let modelUsed = candidateModels[0];
    let spokenObservations: SpokenWordObservation[] | string = '';
    let audioClarity: 'clear' | 'noisy' | 'unintelligible' = 'clear';
    let lastModelErr: unknown = null;
    let succeeded = false;

    for (const candidate of candidateModels) {
      const supportsStructuredSchema = !candidate.includes('transcribe');
      const supportsThinking =
        supportsStructuredSchema &&
        (candidate.startsWith('gemini-4') || candidate.startsWith('gemini-3'));
      try {
        if (supportsStructuredSchema) {
          const transcriptionResponse = await withTimeout(
            ai.models.generateContent({
              model: candidate,
              contents: {
                parts: [
                  {
                    inlineData: {
                      mimeType: mimeType || 'audio/webm',
                      data: audioBase64,
                    },
                  },
                  {
                    text: [
                      'You are a strict Arabic acoustic-phonetic transcriber (NOT a text corrector).',
                      'Listen purely to the physical speech sounds in the audio clip and transcribe word by word.',
                      'CRITICAL ANTI-AUTOCORRECT RULES:',
                      '1) NEVER guess, predict, or autocorrect to standard Quranic verses from memory. The speaker may deliberately alter consonants or vowels to test pronunciation accuracy (for example: saying "الدِّين" with alveolar stop [d] instead of "الَّذِينَ" with interdental fricative [ð], saying "سِراط" instead of "صِراط", or "أَنْعَمْتُ" instead of "أَنْعَمْتَ").',
                      '2) Carefully distinguish minimal-pair Makharij by ear: ذ vs د vs ز | ث vs ت vs س | ظ vs ض vs ذ | ص vs س | ط vs ت | ق vs ك | ح vs هـ | ع vs أ/ء | غ vs خ.',
                      '3) Write the exact Arabic word literally as articulated, including ONLY the harakat and shaddah you actually hear.',
                      '4) If the clip is silent, noise-only, music/hum, a steady tone, or lacks distinct human speech syllables, NEVER guess or invent "بسم الله الرحمن الرحيم" or any Quranic text — return audioClarity="unintelligible" and words=[].',
                      '5) Rate acoustic articulation confidence (0.0 to 1.0) per word; set < 0.55 if muffled or uncertain.',
                    ].join('\n'),
                  },
                ],
              },
              config: {
                ...(supportsThinking
                  ? {thinkingConfig: {thinkingLevel: ThinkingLevel.MEDIUM}}
                  : {}),
                responseMimeType: 'application/json',
                responseSchema: {
                  type: Type.OBJECT,
                  properties: {
                    audioClarity: {
                      type: Type.STRING,
                      enum: ['clear', 'noisy', 'unintelligible'],
                    },
                    words: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          spokenText: {type: Type.STRING},
                          confidence: {type: Type.NUMBER},
                        },
                        required: ['spokenText', 'confidence'],
                      },
                    },
                  },
                  required: ['audioClarity', 'words'],
                },
              },
            }),
            10000,
            `Transcription(${candidate})`
          );

          const rawJson = (transcriptionResponse.text ?? '').trim();
          try {
            const parsed = JSON.parse(rawJson) as {
              audioClarity?: 'clear' | 'noisy' | 'unintelligible';
              words?: Array<{spokenText?: string; confidence?: number}>;
            };
            if (
              parsed.audioClarity === 'clear' ||
              parsed.audioClarity === 'noisy' ||
              parsed.audioClarity === 'unintelligible'
            ) {
              audioClarity = parsed.audioClarity;
            }
            if (Array.isArray(parsed.words)) {
              spokenObservations = parsed.words
                .filter((w) => typeof w.spokenText === 'string' && w.spokenText.trim().length > 0)
                .map((w) => ({
                  text: w.spokenText!.trim(),
                  confidence:
                    typeof w.confidence === 'number'
                      ? Math.max(0, Math.min(1, w.confidence))
                      : 0.85,
                }));
            }
          } catch {
            spokenObservations = rawJson;
          }
        } else {
          const transcriptionResponse = await withTimeout(
            ai.models.generateContent({
              model: candidate,
              contents: {
                parts: [
                  {
                    inlineData: {
                      mimeType: mimeType || 'audio/webm',
                      data: audioBase64,
                    },
                  },
                  {
                    text: 'استمع صوتياً بدقة واكتب فقط الكلمات العربية كما نُطقت حرفياً (مع التمييز الصارم بين الذال والدال، والظاء والضاد، والصاد والسين، والثاء والتاء، والحاء والهاء) دون تصحيح تلقائي من الذاكرة القرآنية.',
                  },
                ],
              },
            }),
            10000,
            `Transcribe(${candidate})`
          );
          spokenObservations = (transcriptionResponse.text ?? '').trim();
        }

        modelUsed = candidate;
        succeeded = true;
        break;
      } catch (err) {
        lastModelErr = err;
        if (!isRetryableModelError(err)) {
          throw err;
        }
      }
    }

    if (!succeeded) {
      throw lastModelErr ?? new Error('لم يتم العثور على نموذج صوتي متاح عبر API.');
    }

    let alignment = alignRecitationWords(spokenObservations, expectedAyahs, {
      audioClarity,
      focusSurahNumber,
      focusAyahNumber,
    });

    let tajweedFindings: TajweedRuleEvaluation[] = [];
    let tajweedCalibrated = false;
    let tajweedNote =
      'لم تتوفر إشارة صوتية كافية لتقييم أحكام التجويد ومخارج الحروف بدقة.';

    const targets = extractSensitiveTajweedTargets(alignment.words);
    const canRunForensicAudit =
      !modelUsed.includes('transcribe') &&
      alignment.audioClarity !== 'unintelligible' &&
      alignment.words.length > 0;

    if (canRunForensicAudit) {
      try {
        const wordSummary = alignment.words
          .map(
            (w, idx) =>
              `[${idx}] expected="${w.expected}" | initialTranscript="${w.spoken ?? ''}"`
          )
          .join('\n');
        const targetChecklist =
          targets.length > 0
            ? targets
                .map((t) => `wordIndex=${t.wordIndex} ("${t.word}"): ${t.checkpoints.join(' ؛ ')}`)
                .join('\n')
            : 'راجع المخارج الحساسة والمدود والغنن المسموعة في الكلمات المتطابقة.';

        const auditModel =
          candidateModels.find((m) => m === modelUsed && !m.includes('transcribe')) ??
          candidateModels.find((m) => !m.includes('transcribe')) ??
          modelUsed;
        const auditThinking =
          auditModel.startsWith('gemini-4') || auditModel.startsWith('gemini-3');

        const auditResponse = await withTimeout(
          ai.models.generateContent({
            model: auditModel,
            contents: {
              parts: [
                {
                  inlineData: {
                    mimeType: mimeType || 'audio/webm',
                    data: audioBase64,
                  },
                },
                {
                  text: [
                    'You are a strict Quranic Tajweed & Phonetic Examiner (مُقرئ مدقق صارم).',
                    'Re-examine the ACTUAL audio waveform carefully against these aligned words and checkpoints.',
                    'DO NOT be lenient or assume the reader recited the Quranic word properly just because ASR wrote it!',
                    '',
                    'Aligned words:',
                    wordSummary,
                    '',
                    'Specific phonetic & Tajweed checkpoints to verify acoustically in the recording:',
                    targetChecklist,
                    '',
                    'Instructions:',
                    '1) In makhrajAudit[], check each sensitive word index: did the speaker physically articulate the exact Makhraj and Harakah? Specifically catch minimal-pair swaps like د instead of ذ (e.g. الدِّين instead of الَّذِينَ), س instead of ص, ت instead of ط, د instead of ض, ز/ذ instead of ظ, أ instead of ع, هـ instead of ح, or wrong final vowels / dropped shaddah. Set verdict="substituted" or "harakah_error" whenever you hear a real deviation, "uncertain" if audio/mic hides it, and "accurate" ONLY if clearly articulated.',
                    '2) In tajweedFindings[], evaluate actual audible Tajweed rules (الغُنّة، المدود، القلقلة، التفخيم والترقيق، مخارج الحروف) with status="correct" | "needs_attention" | "uncertain" and a clear concise Arabic detail.',
                    '3) Never claim 100% perfection if a consonant/duration was rushed, missing, or masked by mic noise.',
                  ].join('\n'),
                },
              ],
            },
            config: {
              ...(auditThinking ? {thinkingConfig: {thinkingLevel: ThinkingLevel.MEDIUM}} : {}),
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  makhrajAudit: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        wordIndex: {type: Type.INTEGER},
                        expectedWord: {type: Type.STRING},
                        expectedLetter: {type: Type.STRING},
                        heardLetter: {type: Type.STRING},
                        verdict: {
                          type: Type.STRING,
                          enum: ['accurate', 'substituted', 'harakah_error', 'uncertain'],
                        },
                        reason: {type: Type.STRING},
                        confidence: {type: Type.NUMBER},
                      },
                      required: ['wordIndex', 'verdict', 'reason', 'confidence'],
                    },
                  },
                  tajweedFindings: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        word: {type: Type.STRING},
                        rule: {type: Type.STRING},
                        status: {
                          type: Type.STRING,
                          enum: ['correct', 'needs_attention', 'uncertain'],
                        },
                        detail: {type: Type.STRING},
                        confidence: {type: Type.NUMBER},
                      },
                      required: ['word', 'rule', 'status', 'detail', 'confidence'],
                    },
                  },
                },
                required: ['makhrajAudit', 'tajweedFindings'],
              },
            },
          }),
          14000,
          `TajweedAudit(${auditModel})`
        );

        const auditParsed = JSON.parse((auditResponse.text ?? '').trim()) as {
          makhrajAudit?: AcousticMakhrajFinding[];
          tajweedFindings?: TajweedRuleEvaluation[];
        };

        if (Array.isArray(auditParsed.makhrajAudit)) {
          alignment = applyAcousticMakhrajAndTajweedAudit(
            alignment,
            auditParsed.makhrajAudit
          );
        }

        if (Array.isArray(auditParsed.tajweedFindings)) {
          tajweedFindings = auditParsed.tajweedFindings
            .filter(
              (f) =>
                typeof f.word === 'string' &&
                typeof f.rule === 'string' &&
                typeof f.detail === 'string'
            )
            .map((f) => ({
              word: f.word.trim(),
              rule: f.rule.trim(),
              status:
                f.status === 'correct' ||
                f.status === 'needs_attention' ||
                f.status === 'uncertain'
                  ? f.status
                  : 'uncertain',
              detail: f.detail.trim(),
              confidence:
                typeof f.confidence === 'number'
                  ? Math.max(0, Math.min(1, f.confidence))
                  : 0.7,
            }));
          tajweedCalibrated = tajweedFindings.length > 0;
          tajweedNote = tajweedCalibrated
            ? 'تم تدقيق مخارج الحروف الحساسة وأحكام التجويد المسموعة (المدود، الغنن، القلقلة، التفخيم) مباشرة من الموجة الصوتية.'
            : 'لم تُرصد أحكام تجويدية كافية في هذا المقطع القصير.';
        }
      } catch {
        tajweedCalibrated = false;
        tajweedNote =
          'تم فحص مطابقة الكلمات والحروف؛ تعذر إكمال التدقيق التجويدي الصوتي في هذه المحاولة.';
      }
    }

    const correctCount = tajweedFindings.filter((f) => f.status === 'correct').length;
    const needsAttentionCount = tajweedFindings.filter(
      (f) => f.status === 'needs_attention'
    ).length;
    const uncertainCount = tajweedFindings.filter((f) => f.status === 'uncertain').length;

    return jsonResponse({
      modelUsed,
      alignment,
      tajweedStatus: {
        calibrated: tajweedCalibrated,
        correctCount,
        needsAttentionCount,
        uncertainCount,
        findings: tajweedFindings,
        note: tajweedNote,
      },
    });
  } catch (err) {
    return jsonResponse(
      {error: err instanceof Error ? err.message : 'فشل تحليل التلاوة عبر الخادم'},
      502
    );
  }
}

export default async function handler(req: Request): Promise<Response> {
  const url = new URL(req.url);
  const pathname = url.pathname
    .replace(/^\/\.netlify\/functions\/api/, '/api')
    .replace(/\/+$/, '');

  const pageMatch = pathname.match(/^\/api\/mushaf\/page\/(\d+)$/);
  if (req.method === 'GET' && pageMatch) {
    const page = Number.parseInt(pageMatch[1], 10);
    if (!Number.isFinite(page) || page < 1 || page > TOTAL_PAGES) {
      return jsonResponse({error: 'Page must be between 1 and 604'}, 400);
    }
    return handleMushafPage(page);
  }

  const tafsirMatch = pathname.match(/^\/api\/mushaf\/tafsir\/(\d+)$/);
  if (req.method === 'GET' && tafsirMatch) {
    const page = Number.parseInt(tafsirMatch[1], 10);
    if (!Number.isFinite(page) || page < 1 || page > TOTAL_PAGES) {
      return jsonResponse({error: 'Page must be between 1 and 604'}, 400);
    }
    return handleTafsirPage(page);
  }

  if (req.method === 'GET' && pathname === '/api/recitation/status') {
    return handleRecitationStatus();
  }

  if (req.method === 'POST' && pathname === '/api/recitation/analyze') {
    return handleRecitationAnalyze(req);
  }

  return jsonResponse({error: 'نقطة API المطلوبة غير موجودة.'}, 404);
}
